enum StatusRequest {
  none  , 
  loading , 
  success , 
  failure , 
  serverfailure , 
  serverException , 
  offlinefailure 
}